package com.example.CertifacteProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CertifacteProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
