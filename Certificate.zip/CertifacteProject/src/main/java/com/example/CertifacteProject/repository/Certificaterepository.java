package com.example.CertifacteProject.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.CertifacteProject.model.Certificate;

public interface Certificaterepository  extends JpaRepository <Certificate, Long>{

}
