package com.example.CertifacteProject.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.CertifacteProject.model.Certificate;
import com.example.CertifacteProject.service.Certificateservice;


@RestController
@CrossOrigin(allowedHeaders ="+", origins ="+")

public class Certificatecontroller {
	 	   @Autowired
			   private Certificateservice certificatesevice;
			   
			   @PostMapping("/addcertificate")
			   public Certificate registerCertificate(@RequestBody Certificate certificate)
			   {
				   return certificatesevice.registerCertificate(certificate);
			   }
			   
			   @GetMapping("/searchStudent")
			   public  List<Certificate> getCertificate() 
			   {
				return certificatesevice.getCertificate();
			   }
			  
			   
			   @PutMapping("/updateCertificate")public Certificate updateCertificate(@RequestBody Certificate certificate){
				   return certificatesevice.updateCertificate(certificate);
			   }
			   
			   @DeleteMapping("/deleteCertificate/{id}")
			   public String delete(@PathVariable Long id){
				   try
				   {
					   Boolean bool=certificatesevice.deleteById(id);
				       if(bool=true)
				       {
				    	   return "successfully deleted";
				       }
				       else return "unsuccessfull";
				   }
				   catch(Exception e)
				   {
					   return "successfull";
				   }
			   }
			
		}

