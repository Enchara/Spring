package com.example.CertifacteProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CertifacteProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(CertifacteProjectApplication.class, args);
	}

}
