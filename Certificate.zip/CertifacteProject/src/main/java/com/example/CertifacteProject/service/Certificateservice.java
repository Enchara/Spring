package com.example.CertifacteProject.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.CertifacteProject.model.Certificate;
import com.example.CertifacteProject.repository.Certificaterepository;


@Service
@Transactional

public class Certificateservice {

		@Autowired
		private Certificaterepository certificaterepository;
		//create
		public Certificate registerCertificate(Certificate certificate){
			 return certificaterepository.save(certificate);
		}
		//read
		public List<Certificate> getCertificate(){
			return (List<Certificate> )certificaterepository.findAll();
		}
		
		//update
		public Certificate updateCertificate(Certificate certificate){
			Long id =certificate.getId();
			Certificate cer =certificaterepository.findById(id).get();
			cer.setYear(certificate.getYear());
			cer.setCollege(certificate.getCollege());
			return certificaterepository.save(cer);
			
		}
		//delete
		public Boolean deleteById (Long id)
		{
			Boolean b=false;
			try{
			certificaterepository.deleteById(id);
			b=true;
		}
			catch (Exception e){
				e.printStackTrace();
			}
			return b;
			}

		}


